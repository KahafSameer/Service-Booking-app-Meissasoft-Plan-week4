const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Service = require('../models/Service');
const auth = require('../middleware/auth');


router.post('/:serviceId', auth, async (req, res) => {
    const { serviceId } = req.params;

    try {
        // Atomic check and update to prevent race conditions
        const service = await Service.findOneAndUpdate(
            {
                _id: serviceId,
                $expr: { $lt: ["$currentBookings", "$maxBookings"] }
            },
            { $inc: { currentBookings: 1 } },
            { new: true }
        );

        if (!service) {
            // Check if it failed because it doesn't exist or because it's full
            const exists = await Service.findById(serviceId);
            if (!exists) {
                return res.status(404).json({ message: 'Service not found' });
            }
            return res.status(400).json({ message: 'Service is fully booked' });
        }

        try {
            const booking = new Booking({
                service: serviceId,
                user: req.user.id, // Fixed: req.user contains { id, role }, not _id
            });

            await booking.save();
            res.status(201).json({ message: 'Booking created successfully', booking });
        } catch (bookingError) {
            // Rollback the increment if booking creation fails
            console.error("Booking error, rolling back:", bookingError);
            await Service.findByIdAndUpdate(serviceId, { $inc: { currentBookings: -1 } });
            throw bookingError; // Re-throw to hit outer catch
        }

    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "server error" });
    }
});


router.get('/my', auth, async (req, res) => {
    try {
        const bookings = await Booking.find({ user: req.user._id }).populate('service');
        res.json(bookings);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "server error" });
    }
});


router.get("/", auth, async (req, res) => {
    try {
        //rolback
        if (req.user.role !== 'admin') {
            return res.status(403).json({ message: 'Access denied' });
        }
        const bookings = await Booking.find().populate('service').populate('user', 'name email');
        res.json(bookings);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: "server error" });
    }
});


module.exports = router;